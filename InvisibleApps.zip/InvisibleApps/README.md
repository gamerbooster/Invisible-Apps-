# Invisible Apps

Proyecto inicial para Android Studio (Kotlin).

## Qué hace esta versión
- Funciona como un lanzador (launcher) alternativo de Android.
- Muestra las aplicaciones que Android permite consultar.
- Permite marcar aplicaciones para ocultarlas de la pantalla principal de **este launcher**.
- Guarda la selección en el dispositivo.

## Límites importantes
- Android no permite que una aplicación normal cambie el nombre/icono real de otras apps ni que las quite del launcher original o de Ajustes.
- Para que una app no aparezca en el cajón normal, hay que elegir Invisible Apps como aplicación de Inicio predeterminada y usar su pantalla de inicio.
- Las apps ocultas siguen instaladas y pueden seguir apareciendo en Ajustes. No las desinstala ni bloquea.
- La búsqueda de apps instaladas está sujeta a las restricciones de visibilidad de paquetes de Android.

## Abrir
1. Descomprime el ZIP.
2. Abre la carpeta `InvisibleApps` desde Android Studio.
3. Espera la sincronización de Gradle y ejecuta en un teléfono Android.
4. Pulsa Inicio y selecciona **Invisible Apps** como aplicación de inicio para probarlo.

Este es un proyecto fuente inicial, no un APK compilado.
