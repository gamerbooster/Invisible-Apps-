package com.example.invisibleapps

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class HomeActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("invisible_apps", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
        }
        root.addView(TextView(this).apply {
            text = "Invisible Apps"
            textSize = 28f
        })
        root.addView(Button(this).apply {
            text = "Configurar aplicaciones"
            setOnClickListener { startActivity(Intent(this@HomeActivity, MainActivity::class.java)) }
        })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName && it.activityInfo.packageName !in hidden }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        for (info in apps) {
            val pkg = info.activityInfo.packageName
            val button = Button(this).apply {
                text = info.loadLabel(pm).toString()
                compoundDrawablePadding = 12
                setCompoundDrawablesWithIntrinsicBounds(info.loadIcon(pm), null, null, null)
                setOnClickListener {
                    val launch = pm.getLaunchIntentForPackage(pkg)
                    if (launch != null) startActivity(launch)
                    else Toast.makeText(this@HomeActivity, "No se puede abrir esta app", Toast.LENGTH_SHORT).show()
                }
            }
            list.addView(button, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(root)
    }
}
