package com.example.invisibleapps

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("invisible_apps", MODE_PRIVATE) }
    private val hidden = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hidden.addAll(prefs.getStringSet("hidden", emptySet()) ?: emptySet())

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
        }
        root.addView(TextView(this).apply {
            text = "Invisible Apps"
            textSize = 28f
        })
        root.addView(TextView(this).apply {
            text = "Elegí qué aplicaciones mostrar en el inicio de Invisible Apps. Esto no las oculta de Ajustes ni de otros launchers."
            textSize = 14f
            setPadding(0, 12, 0, 18)
        })
        root.addView(Button(this).apply {
            text = "Abrir mi inicio"
            setOnClickListener { startActivity(Intent(this@MainActivity, HomeActivity::class.java)) }
        })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        for (info in apps) {
            val pkg = info.activityInfo.packageName
            if (pkg == packageName) continue
            val check = CheckBox(this).apply {
                text = info.loadLabel(pm).toString()
                textSize = 16f
                isChecked = pkg !in hidden
                setOnCheckedChangeListener { _, checked ->
                    if (checked) hidden.remove(pkg) else hidden.add(pkg)
                    prefs.edit().putStringSet("hidden", hidden.toSet()).apply()
                }
            }
            list.addView(check, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(root)
    }
}
